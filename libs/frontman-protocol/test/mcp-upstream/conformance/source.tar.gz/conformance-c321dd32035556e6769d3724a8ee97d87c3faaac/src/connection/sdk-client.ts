/**
 * Helper utilities for creating MCP clients to test servers
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import {
  LoggingMessageNotificationSchema,
  ProgressNotificationSchema,
  type JSONRPCMessage,
  type MessageExtraInfo
} from '@modelcontextprotocol/sdk/types.js';
import type { Transport } from '@modelcontextprotocol/sdk/shared/transport.js';

import { type SpecVersion } from '../types';
import {
  validateWireMessage,
  type WireOrigin
} from '../validation/wire-schema';
import type { ConnectOptions } from './index';

const DEFAULT_CLIENT_INFO = {
  name: 'conformance-test-client',
  version: '1.0.0'
} as const;

const DEFAULT_CAPABILITIES = {
  sampling: {},
  elicitation: {}
} as const;

export interface MCPClientConnection {
  client: Client;
  close: () => Promise<void>;
}

/** Hook an SDK transport so every raw wire message, both directions (handshake included,
 * no bypass), is schema-validated. Outbound = harness origin, inbound = implementation;
 * request ids are tracked per direction to validate responses against typed results. */
function instrumentTransport(
  transport: Transport,
  specVersion: SpecVersion
): void {
  // Request id → method, per direction. An entry is consumed by the response
  // travelling the opposite way, so the maps stay bounded.
  const harnessRequests = new Map<string | number, string>();
  const implementationRequests = new Map<string | number, string>();

  const validate = (message: unknown, origin: WireOrigin): void => {
    const ownRequests =
      origin === 'harness' ? harnessRequests : implementationRequests;
    const peerRequests =
      origin === 'harness' ? implementationRequests : harnessRequests;
    // `send` accepts arrays (2025-03-26 batches); walk elements for request/
    // response bookkeeping, validating singles here and batches whole below.
    for (const m of Array.isArray(message) ? message : [message]) {
      const msg = (typeof m === 'object' && m !== null ? m : {}) as Record<
        string,
        unknown
      >;
      const id = msg.id as string | number | undefined;
      let context: string;
      let requestMethod: string | undefined;
      if (typeof msg.method === 'string') {
        if (id !== undefined) {
          ownRequests.set(id, msg.method);
          context = `stateful request '${msg.method}'`;
        } else {
          context = `stateful notification '${msg.method}'`;
        }
      } else {
        requestMethod = id !== undefined ? peerRequests.get(id) : undefined;
        if (id !== undefined) peerRequests.delete(id);
        context = `stateful response to '${requestMethod ?? `id ${String(id)}`}'`;
      }
      if (!Array.isArray(message)) {
        validateWireMessage(specVersion, m, { origin, context, requestMethod });
      }
    }
    if (Array.isArray(message)) {
      // One whole-array validation covers per-element errors (prefixed [i])
      // and batch legality for the version; validating the elements in the
      // loop above too would record every violation twice.
      validateWireMessage(specVersion, message, {
        origin,
        context: 'stateful batch'
      });
    }
  };

  const originalSend = transport.send.bind(transport);
  transport.send = (message, options) => {
    validate(message, 'harness');
    return originalSend(message, options);
  };

  // The SDK's protocol layer assigns `onmessage` during `client.connect()`;
  // intercept the assignment so the validator sees every inbound message
  // before the handler does.
  let inner:
    | ((message: JSONRPCMessage, extra?: MessageExtraInfo) => void)
    | undefined;
  const wrapped = (message: JSONRPCMessage, extra?: MessageExtraInfo): void => {
    validate(message, 'implementation');
    inner?.(message, extra);
  };
  Object.defineProperty(transport, 'onmessage', {
    configurable: true,
    enumerable: true,
    get: () => (inner === undefined ? undefined : wrapped),
    set: (handler: typeof inner) => {
      inner = handler;
    }
  });
}

/**
 * Create and connect an MCP client to a server. `opts.capabilities` and
 * `opts.clientInfo` override the harness defaults — scenarios that
 * negotiate extensions (tasks, EMA, ...) pass them through to drive a
 * conformant `initialize`. The transport is instrumented so every wire
 * message in both directions is validated against `specVersion`'s spec
 * JSON schema; scenarios that call this directly pass `ctx.specVersion`.
 *
 * The returned `close()` sends an HTTP DELETE to terminate the server-side
 * session (per the Streamable HTTP transport spec) before closing the client,
 * so each scenario leaves the server hermetic. A server that responds 405
 * (DELETE not supported) is tolerated, since the spec allows that.
 */
export async function connectToServer(
  serverUrl: string,
  opts: ConnectOptions,
  specVersion: SpecVersion
): Promise<MCPClientConnection> {
  const client = new Client(opts.clientInfo ?? DEFAULT_CLIENT_INFO, {
    capabilities: opts.capabilities ?? DEFAULT_CAPABILITIES
  });

  const transport = new StreamableHTTPClientTransport(new URL(serverUrl));
  instrumentTransport(transport, specVersion);

  await client.connect(transport);

  return {
    client,
    close: async () => {
      await terminateSessionBestEffort(transport, serverUrl);
      await client.close();
    }
  };
}

// Shared teardown bound so a wedged server-under-test cannot stall the suite.
const SESSION_TERMINATE_TIMEOUT_MS = 5000;

/**
 * Best-effort session termination for an SDK transport. Delegates to
 * terminateSessionRaw (with the transport's negotiated protocol version) so
 * the DELETE is truly bounded — the socket is aborted at the timeout rather
 * than left pending against a wedged server. No-op when the server never
 * issued a session.
 */
export async function terminateSessionBestEffort(
  transport: StreamableHTTPClientTransport,
  serverUrl: string
): Promise<void> {
  if (!transport.sessionId || !transport.protocolVersion) return;
  await terminateSessionRaw(
    serverUrl,
    transport.sessionId,
    transport.protocolVersion
  );
}

/**
 * Best-effort HTTP DELETE to terminate a raw (non-SDK) session.
 *
 * Used by scenarios that open sessions via raw `fetch` instead of going through
 * the SDK's StreamableHTTPClientTransport. Failures are swallowed because the
 * spec allows servers to respond 405, and cleanup must not derail the scenario.
 */
export async function terminateSessionRaw(
  serverUrl: string,
  sessionId: string,
  protocolVersion: string
): Promise<void> {
  try {
    await fetch(serverUrl, {
      method: 'DELETE',
      headers: {
        'mcp-session-id': sessionId,
        'MCP-Protocol-Version': protocolVersion
      },
      signal: AbortSignal.timeout(SESSION_TERMINATE_TIMEOUT_MS)
    });
  } catch {
    // best-effort cleanup
  }
}

/**
 * Helper to collect notifications (logging and progress)
 */
export class NotificationCollector {
  private loggingNotifications: any[] = [];
  private progressNotifications: any[] = [];

  constructor(client: Client) {
    // Set up notification handler for logging messages
    client.setNotificationHandler(
      LoggingMessageNotificationSchema,
      (notification) => {
        this.loggingNotifications.push(notification);
      }
    );

    // Set up notification handler for progress notifications
    client.setNotificationHandler(
      ProgressNotificationSchema,
      (notification) => {
        this.progressNotifications.push(notification);
      }
    );
  }

  /**
   * Get all collected logging notifications
   */
  getLoggingNotifications(): any[] {
    return this.loggingNotifications;
  }

  /**
   * Get all collected progress notifications
   */
  getProgressNotifications(): any[] {
    return this.progressNotifications;
  }

  /**
   * Get all notifications (for backward compatibility)
   */
  getNotifications(): any[] {
    return this.loggingNotifications;
  }
}
